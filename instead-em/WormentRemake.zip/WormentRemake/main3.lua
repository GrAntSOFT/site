-- $Name:Червемент-ремейк$
-- $Version:1.0.1$
-- $Author:GrAntSOFT [Гринблат Антон]$
 std.dofile = std.doencfile;
require 'snd';
 require 'noinv';
 require 'fmt'; -- некоторые функции форматирования
 fmt.para = true; -- включить режим параграфов (отступы) 
 game.codepage='UTF-8';
 include 'level0';
 include 'level1';
 include 'level2';
