-- $Name:zero_source (en)$
-- $Version:1.0.0$
-- $Author:GrAntSOFT [Anton Grinblat]$
-- $Info: Translate and imgs by\n Yandex Alise AI.\n Some edit by Lucky Ook$

--[[ At the very beginning of the game file, 
   the game name, version, and author must be specified 
   in the form of special comments enclosed between 
   two dollar signs. This will be required for publication 
   on instead-games ]]

--[[ The name of the main game file must be main3.lua 
   so that the interpreter recognizes it as code for 
   Instead version 3 or higher. The name of the first room 
   must be main ]]

-- Connecting the minimally required modules
--require 'dbg'; -- Debugging, essential for game development
require 'fmt'; -- Text formatting functions
require 'noinv'; -- Sometimes it's useful to hide the inventory
fmt.para = false; -- Disable indentation mode for better appearance
game.codepage='UTF-8'; -- Everything must be in UTF-8 format, including every Lua game file

-- This function will respond to the player with a default line 
-- if they perform an action not provided for in the quest line. 
-- In other words, it's the default response for an incorrect action
game.use = function ()
   return('This will not lead to the desired result.');
end;

-- That's it. It's better not to load anything else into the system startup file. 
-- Instead, distribute the rooms across separate files (one room per file) 
-- and connect them to the project using dofile directives
dofile 'room0.lua';
dofile 'room1.lua';
dofile 'room2.lua';
dofile 'room3.lua';
