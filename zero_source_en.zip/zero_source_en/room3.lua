------------------------------
-- room3 room, win screen --
------------------------------

room3 = room {
   nam = 'room3'; -- set the system name of the room
   title = 'Win!'; -- title displayed at the top of the game screen
   noinv = true; -- hide inventory from the win screen
   decor = function ()
      p('The cat is well fed, petted, and purring gratefully. You\'ve won!');
      if have('courgette') then
         p('^(But there\'s still the question of what to do with the zucchini...)');
      end;
   end;
   
   pic = 'cat0.jpg'; -- set the image
}
