-- The project will not start without a room named 'main' — this is a mandatory requirement
-- It is recommended to use this room as the very start of the game, for example, as a title page

-------------------------------------------
-- Primary room 'main', title page --
-------------------------------------------

main = room {
   nam = 'main'; -- set the required room name
   title = 'Main Room, Title Page'; -- title displayed at the top of the game screen
   decor = fmt.c 'The Title Page of My Game!^Welcome!^To start the game click {next_room|Next>>>}'; -- set static description, the fmt.c(string) - place in the center;
   pic = 'title.jpg'; -- set the image
}:with {'next_room'} -- this is the list of room objects, here there is only one — next_room, its description is below
--------------

-- Objects of the 'main' room:

-- transition object to the next room, "next room"
next_room = obj {
   nam = 'next_room'; -- object name
   act = function() -- act — function executed when the object is clicked once with the mouse
      walk('room1'); -- upon click, send the player to room №1
   end;   
}
