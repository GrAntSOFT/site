---------------------------------
-- room1 room, cat's room --
---------------------------------

room1 = room {
   nam = 'room1'; -- set the system name of the room
   way = {'room2'}; -- set possible room transitions
   title = 'Cat\'s Room'; -- title displayed at the top of the game screen
   disp = 'To the cat\'s room'; -- set the displayed room name, this is what will appear in transitions
   decor = function()
      local cat_state = "";
      if cat.hungry then
         cat_state = "hungry";
      else
         cat_state = "well-fed";
      end;
      return [[You are in the cat's room. There is a table in front of you, a {opener|can opener} is on the table, next to an empty {plate|bowl} sits a ]]..cat_state..[[ {cat|cat}, looking at you pitifully.]]; -- set static description, inform the player about the objective
   end;
   pic = function()
      if cat.hungry then
          return'catroom.jpg'; -- set the image of hungry cat
      else
         return'catroom1.jpg'; -- or set the image of well-fed cat
      end;
   end;
}:with {'opener','cat','plate','pet_cat'} -- list of room objects, separated by commas if there are many

------------------------
-- room1 objects:

-- cat object
cat = obj {
   nam = 'cat'; -- object name
   hungry = true;
   act = function()
    if cat.hungry then
      return 'The cat meows pitifully and doesn\'t let you pet it.';
    else
      walk ('room3');
      return 'You petted well-fed cat, the cat purrs gratefully!';
    end;
   end;
}

-- can opener
opener = obj {
   nam = 'opener'; -- object name
   act = 'Automatic can opener, standard model.';
   used = function(s,w) -- used function checks if the player is using the correct inventory item on this object, s - self (the object itself), w - with (the item being used)
      if w^'can' and can.sealed then
         p('You place the can in the opener. After a few seconds of unpleasant buzzing, you take the opened can.');
         can.sealed=false;
         return; -- each correct action requires a return from the function to prevent incorrect action comments from being added
      end;      
      return(false); -- for complex games, it\'s mandatory to have return false at the end to show the player they didn\'t perform any of the quest\'s intended actions
   end;   
}

-- bowl
plate = obj {
   nam = 'plate'; -- object name
   act = 'There\'s no need to pick up the bowl from the floor.';
   used = function (s,w)
      if w^'can' and not can.sealed then
         p('The cat, purring gratefully, approaches the bowl and starts eating delicious food from it. You have won and can now {pet_cat|pet the cat!}');
         cat.hungry = false;
         remove(w) -- remove empty food can from inventory
         return;
      end;
      return(false);
   end;
   
}

-- winning object - "pet the cat"
pet_cat = obj {
   nam = 'pet_cat';
   act = function()
      walk('room3');
      return 'You petted well-fed cat, the cat purrs gratefully!';
   end;   
}
