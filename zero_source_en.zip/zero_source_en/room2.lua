------------------------------
-- room2 room, pantry --
------------------------------

room2 = room {
   nam = 'room2'; -- set the system name of the room
   disp = 'To the Pantry'; -- set the displayed room name, this is what will appear in transitions
   way = {'room1'}; -- set possible room transitions
   title = 'Pantry'; -- title displayed at the top of the game screen
   pic = function(s)
		if here() == where(courgette) then
			return'food_cans1.png' -- show this image if we didn't take the zucchini. 
		else
			return'food_cans.jpg' -- show this image if we took the zucchini and, therefore, it is no longer in the room.
		end
   end;
   decor = function () -- decor depends on game circumstances, must be a function, not just a string
      p('You are in the pantry. Shadows of shelves with {food_cans|cat food cans} can be seen in the darkness.'); -- set static description, inform the player about the objective
      if seen('courgette') then -- dynamic part of room description, appears only if the player hasn\'t picked up the zucchini yet
         p('A dusty {courgette|zucchini} lies on the floor.');
      end;
   end;
}:with {'food_cans','courgette'} -- list of room objects

------------------------
-- room2 objects:

-- food cans on shelves
food_cans = obj {
   nam = 'food_cans'; -- object name
   act = function()
      if not have('can') then
         take('can');
         p('You took a can of food.');
      else
         p('You have already taken a can of food.');
      end;      
   end;   
}

-- food can for inventory
can = obj {
   nam = 'can'; -- object name
   disp = 'food can'; -- displayed name, visible in inventory
   sealed = true; -- initially sealed
   inv = function(s) -- inv is called when player double-clicks inventory item or uses item on itself, s is self reference to the object
      p('This is a can of cat food.');
      if s.sealed then -- using s reference to the can, though can.sealed could also be used
         p('It\'s sealed.');
      else
         p('It\'s open.');
      end;      
   end;   
}

-- zucchini
courgette = obj {
   nam = 'courgette'; -- zucchini object name
   disp = 'zucchini'; -- displayed name, visible in inventory
   tak = 'You pick up the zucchini.'; -- tak attribute allows simultaneous description of action, placing item in player\u0027s inventory, and removing it from visible environment objects - in other words, PICKING UP
   inv = 'This is a zucchini.';
}
